tinymce.addI18n("af", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});