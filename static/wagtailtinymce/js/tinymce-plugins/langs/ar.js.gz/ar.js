tinymce.addI18n("ar", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});