tinymce.addI18n("ast", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});