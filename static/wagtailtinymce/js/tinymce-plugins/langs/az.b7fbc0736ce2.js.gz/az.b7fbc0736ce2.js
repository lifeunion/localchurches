tinymce.addI18n("az", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});