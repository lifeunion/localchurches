tinymce.addI18n("be", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});