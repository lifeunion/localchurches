tinymce.addI18n("bn", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});