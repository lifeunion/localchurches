tinymce.addI18n("br", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});