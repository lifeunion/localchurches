tinymce.addI18n("bs", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});