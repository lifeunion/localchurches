tinymce.addI18n("ca", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});