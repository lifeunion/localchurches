tinymce.addI18n("cs", {
"Insert/edit media": "Insert/edit media",
"Documents": "Dokumenty"
});