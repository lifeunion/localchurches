tinymce.addI18n("cy", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});