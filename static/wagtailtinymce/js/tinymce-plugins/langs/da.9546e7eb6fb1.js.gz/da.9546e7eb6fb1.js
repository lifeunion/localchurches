tinymce.addI18n("da", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});