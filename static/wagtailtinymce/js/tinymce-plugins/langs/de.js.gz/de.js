tinymce.addI18n("de", {
"Insert/edit media": "Insert/edit media",
"Documents": "Dokumente"
});