tinymce.addI18n("de_CH", {
"Insert/edit media": "Insert/edit media",
"Documents": "Dokumente"
});