tinymce.addI18n("el", {
"Insert/edit media": "Insert/edit media",
"Documents": "\u0388\u03b3\u03b3\u03c1\u03b1\u03c6\u03b1"
});