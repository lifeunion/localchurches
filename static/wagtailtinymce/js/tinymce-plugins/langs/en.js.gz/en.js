tinymce.addI18n("en", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});