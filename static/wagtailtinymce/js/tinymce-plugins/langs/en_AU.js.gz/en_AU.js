tinymce.addI18n("en_AU", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});