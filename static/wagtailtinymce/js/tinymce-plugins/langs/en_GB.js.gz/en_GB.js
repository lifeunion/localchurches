tinymce.addI18n("en_GB", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});