tinymce.addI18n("eo", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});