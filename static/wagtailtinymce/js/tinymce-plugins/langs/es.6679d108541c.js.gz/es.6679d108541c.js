tinymce.addI18n("es", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documentos"
});