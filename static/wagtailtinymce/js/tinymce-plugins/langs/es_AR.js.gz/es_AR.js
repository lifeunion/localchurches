tinymce.addI18n("es_AR", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documentos"
});