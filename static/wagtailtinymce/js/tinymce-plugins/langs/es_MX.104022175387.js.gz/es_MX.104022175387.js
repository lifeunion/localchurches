tinymce.addI18n("es_MX", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documentos"
});