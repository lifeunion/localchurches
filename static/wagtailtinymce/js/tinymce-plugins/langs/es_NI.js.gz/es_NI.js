tinymce.addI18n("es_NI", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documentos"
});