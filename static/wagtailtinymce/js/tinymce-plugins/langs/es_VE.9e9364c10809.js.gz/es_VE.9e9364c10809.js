tinymce.addI18n("es_VE", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documentos"
});