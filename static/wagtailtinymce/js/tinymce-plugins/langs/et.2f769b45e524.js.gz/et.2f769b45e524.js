tinymce.addI18n("et", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});