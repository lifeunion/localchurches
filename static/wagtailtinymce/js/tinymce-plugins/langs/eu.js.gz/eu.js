tinymce.addI18n("eu", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});