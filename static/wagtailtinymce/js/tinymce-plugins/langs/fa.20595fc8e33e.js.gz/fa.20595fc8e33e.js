tinymce.addI18n("fa", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});