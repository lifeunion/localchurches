tinymce.addI18n("fi", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});