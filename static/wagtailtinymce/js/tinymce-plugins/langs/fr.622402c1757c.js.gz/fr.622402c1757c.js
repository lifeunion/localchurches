tinymce.addI18n("fr", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});