tinymce.addI18n("fy", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});