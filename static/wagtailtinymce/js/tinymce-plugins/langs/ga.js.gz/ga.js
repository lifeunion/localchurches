tinymce.addI18n("ga", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});