tinymce.addI18n("he", {
"Insert/edit media": "Insert/edit media",
"Documents": "\u05de\u05e1\u05de\u05db\u05d9\u05dd"
});