tinymce.addI18n("hi", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});