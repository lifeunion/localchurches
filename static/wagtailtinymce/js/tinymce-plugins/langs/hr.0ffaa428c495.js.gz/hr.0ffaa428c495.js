tinymce.addI18n("hr", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});