tinymce.addI18n("hu", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});