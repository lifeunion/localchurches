tinymce.addI18n("ia", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});