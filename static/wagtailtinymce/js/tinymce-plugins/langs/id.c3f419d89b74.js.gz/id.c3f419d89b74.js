tinymce.addI18n("id", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});