tinymce.addI18n("io", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});