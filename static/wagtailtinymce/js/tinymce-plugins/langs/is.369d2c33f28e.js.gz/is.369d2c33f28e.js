tinymce.addI18n("is", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});