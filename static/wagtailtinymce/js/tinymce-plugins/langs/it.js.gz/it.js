tinymce.addI18n("it", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documenti"
});