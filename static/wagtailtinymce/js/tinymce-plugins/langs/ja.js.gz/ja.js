tinymce.addI18n("ja", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});