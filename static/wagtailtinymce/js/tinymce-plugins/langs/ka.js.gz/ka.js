tinymce.addI18n("ka", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});