tinymce.addI18n("kk", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});