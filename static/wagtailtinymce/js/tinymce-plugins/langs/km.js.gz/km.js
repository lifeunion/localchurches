tinymce.addI18n("km", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});