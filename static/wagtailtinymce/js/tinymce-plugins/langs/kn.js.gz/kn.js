tinymce.addI18n("kn", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});