tinymce.addI18n("lb", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});