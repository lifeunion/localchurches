tinymce.addI18n("lt", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});