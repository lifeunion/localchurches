tinymce.addI18n("lv", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});