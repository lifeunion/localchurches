tinymce.addI18n("mk", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});