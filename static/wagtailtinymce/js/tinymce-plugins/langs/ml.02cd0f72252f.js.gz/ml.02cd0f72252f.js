tinymce.addI18n("ml", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});