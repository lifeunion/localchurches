tinymce.addI18n("mn", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});