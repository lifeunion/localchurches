tinymce.addI18n("mr", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});