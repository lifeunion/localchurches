tinymce.addI18n("my", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});