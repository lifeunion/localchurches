tinymce.addI18n("nb", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});