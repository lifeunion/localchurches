tinymce.addI18n("ne", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});