tinymce.addI18n("nl", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documenten"
});