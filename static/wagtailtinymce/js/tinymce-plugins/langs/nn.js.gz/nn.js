tinymce.addI18n("nn", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});