tinymce.addI18n("os", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});