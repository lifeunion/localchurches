tinymce.addI18n("pa", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});