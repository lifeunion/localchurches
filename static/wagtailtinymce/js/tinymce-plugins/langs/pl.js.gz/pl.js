tinymce.addI18n("pl", {
"Insert/edit media": "Insert/edit media",
"Documents": "Dokumenty"
});