tinymce.addI18n("pt", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documentos"
});