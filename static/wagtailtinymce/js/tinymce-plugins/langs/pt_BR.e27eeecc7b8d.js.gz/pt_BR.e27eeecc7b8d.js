tinymce.addI18n("pt_BR", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documentos"
});