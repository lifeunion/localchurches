tinymce.addI18n("ro", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documente"
});