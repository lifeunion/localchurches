tinymce.addI18n("ru", {
"Insert/edit media": "Insert/edit media",
"Documents": "\u0414\u043e\u043a\u0443\u043c\u0435\u043d\u0442\u044b"
});