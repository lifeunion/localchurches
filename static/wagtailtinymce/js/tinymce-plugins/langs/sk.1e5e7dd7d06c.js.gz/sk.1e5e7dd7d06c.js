tinymce.addI18n("sk", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});