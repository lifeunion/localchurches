tinymce.addI18n("sl", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});