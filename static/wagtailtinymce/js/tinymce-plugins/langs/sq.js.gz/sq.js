tinymce.addI18n("sq", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});