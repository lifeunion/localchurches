tinymce.addI18n("sr", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});