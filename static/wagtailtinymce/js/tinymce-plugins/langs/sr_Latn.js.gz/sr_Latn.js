tinymce.addI18n("sr_Latn", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});