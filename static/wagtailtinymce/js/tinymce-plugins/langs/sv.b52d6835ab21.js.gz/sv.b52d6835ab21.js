tinymce.addI18n("sv", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});