tinymce.addI18n("sw", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});