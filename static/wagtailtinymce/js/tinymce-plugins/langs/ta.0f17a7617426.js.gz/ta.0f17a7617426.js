tinymce.addI18n("ta", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});