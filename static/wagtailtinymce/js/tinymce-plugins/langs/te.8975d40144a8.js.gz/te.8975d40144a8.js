tinymce.addI18n("te", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});