tinymce.addI18n("th", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});