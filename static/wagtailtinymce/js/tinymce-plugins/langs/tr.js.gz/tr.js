tinymce.addI18n("tr", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});