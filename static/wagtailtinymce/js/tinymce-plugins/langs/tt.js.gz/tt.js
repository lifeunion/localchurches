tinymce.addI18n("tt", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});