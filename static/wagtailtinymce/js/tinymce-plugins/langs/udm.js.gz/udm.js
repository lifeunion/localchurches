tinymce.addI18n("udm", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});