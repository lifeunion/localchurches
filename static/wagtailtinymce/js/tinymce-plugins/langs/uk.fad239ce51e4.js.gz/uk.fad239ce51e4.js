tinymce.addI18n("uk", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});