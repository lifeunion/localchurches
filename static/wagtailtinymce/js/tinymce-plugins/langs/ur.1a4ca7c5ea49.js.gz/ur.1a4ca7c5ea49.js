tinymce.addI18n("ur", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});