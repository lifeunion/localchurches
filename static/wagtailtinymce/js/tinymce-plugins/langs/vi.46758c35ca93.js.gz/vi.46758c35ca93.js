tinymce.addI18n("vi", {
"Insert/edit media": "Insert/edit media",
"Documents": "Documents"
});